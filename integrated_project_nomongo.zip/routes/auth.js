const express = require('express');
const router = express.Router();
const users = require('../models/User');

router.post('/signup', (req, res) => {
  const { email, password } = req.body;
  const exists = users.find(u => u.email === email);
  if (exists) return res.status(400).send('User already exists');
  users.push({ email, password });
  res.redirect('/login.html');
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).send('Invalid credentials');
  res.redirect('/homepage.html');
});

module.exports = router;
